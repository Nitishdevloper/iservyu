package interview;

import java.util.*;
public class B {

	public static void nonrepeat(String s)
	{
		for(int i=0;i<s.length();i++)
		{
			if(s.indexOf(s.charAt(i),s.indexOf(s.charAt(i))+1)==-1)
			{
				System.out.println("1st non-repeating letter is:"+s.charAt(i));
				break;
			}
			else
			{
				System.out.println("$");
			}
		}
		return ;
	}
	

	public static void main(String[] args) {
	
		String s="hello";
		nonrepeat(s);

	}

}
