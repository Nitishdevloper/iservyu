package interview;
import java.util.*;
public class C {

	public static void MissingNumber(int arr [],int n)
	{
		int i;
		int temp[]=new int [n+1];
		for(i=0;i<=n;i++)
		{
			temp[i]=0;
			
		}
		
		for(i=0;i<n;i++)
		{
			temp[arr[i]-1]=1;
			
		}
		int  a=0;
		for(i=0;i<=n;i++)
		{
			if(temp[i]==0)
			    a=i+1;
			
		}
		
	System.out.println(a);
	}
	
	
	public static void main(String[] args) {
	 int arr[]= { 1,3,4,5,6,7};
     int n=arr.length;
     
     MissingNumber(arr,n);
	}

}
