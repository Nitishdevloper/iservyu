package interview;

public class A {

	public static void main(String[] args) {
	int arr[]= {2,4,6,3,5};
	 int n=arr.length;
	 int smallest=Integer.MAX_VALUE;
	 
	 for(int i=0;i<n;i++)
	 {
		 if(arr[i]<smallest) {
			 smallest=arr[i];
		 }
	 }
      System.out.println("smallest is"+smallest);
      
      int second_smallest=Integer.MAX_VALUE;
      
      for(int i=0;i<n;i++)
      {
    	  if(arr[i]<second_smallest && arr[i]>smallest)
    	  {
    		  second_smallest=arr[i];  
    	  }
      }
      
	System.out.println("Second smallest element is"+second_smallest);	
    System.out.println("output is:"+smallest*second_smallest);
	}

}
